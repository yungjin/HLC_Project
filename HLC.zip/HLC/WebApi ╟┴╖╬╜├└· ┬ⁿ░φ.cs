////////////////////////////////////////////////////////

// 단순 프로시저 조회 SELECT (값X)
        [Route("select")]
        [HttpGet]
        public ActionResult<ArrayList> Select()
        {
			
            MySqlDataReader sdr = db.HLC_Reader("프로시저이름");
            
        }
		

// 넘어오는 값으로 프로시저 조회 SELECT (값O)		
      [Route("login_form_PW_Select_API")]
		[HttpPost]
		public ActionResult<string> Login_form_PW_Select_API([FromForm] string id)
		{
			
            Hashtable ht = new Hashtable();
            ht.Add("_id", id);
			MySqlDataReader sdr = db.HLC_Reader_Value("프로시저이름", ht);	

		}

		
//HLC_NonQuery_Value 프로시저 실행 할 경우
      [Route("GetUPDATE_Pass_API")]
		[HttpPost]
		public ActionResult<string> GetUPDATE_Pass_API([FromForm] string passwod,[FromForm] string user_number)
		{

            Hashtable ht = new Hashtable();
            ht.Add("_passwod", passwod);
            ht.Add("_user_number", user_number);
            
			//string sql = string.Format("UPDATE signup set passwod = '{0}' where user_number = {1};", passwod, user_number);
			if(db.HLC_NonQuery_Value("프로시저이름", ht))
			{
				return "1";
			}
			else 
			{
				return "0";
			}
            db.Close();
		}

    