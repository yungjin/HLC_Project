/**********************************************************************
 * 구분 문자 처리 : DELIMITER 사용하여 쌍반점(;)을 중간에 사용하여도 
 *                  하나의 명령으로 인식 하도록 처리가 필요
 * 1. procedure 생성 
 * DELIMITER //create procedure 이름
 * () -- 파라메터 설정
 * begin
 * ~~~~~~~~~~~~~~~~~~~ -- SQL문 작성
 * end // DELIMITER;
 * 
 * 2. procedure 생성 확인
 * SHOW CREATE PROCEDURE 이름;
 *
 * 3. procedure 삭제
 * DROP PROCEDURE 이름;
 *
 * 4. procedure parameter 사용
 * 입력 : in (in _name varchar(10), in _age int)
 * 출력 : out (out result)
 * DELIMITER //create procedure 이름
 * (in _name varchar(10), in _age int, out result) -- 파라메터 설정
 * begin 
 * declare _count int; -- 변수선언
 * ~~~~~~~~~~~~~~~~~~~ -- SQL문 작성
 * set result = 0;     -- 변수값 넣기
 * end // DELIMITER;
 *
 * 5. procedure 실행
 * 기본 : call 이름();
 * 파라메터 사용 시 : call 이름('테스트',10, @result); select @result;
 **********************************************************************/