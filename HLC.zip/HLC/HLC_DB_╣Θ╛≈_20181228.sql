-- --------------------------------------------------------
-- 호스트:                          ljh5432.iptime.org
-- 서버 버전:                        10.3.10-MariaDB - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  9.5.0.5295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- gdc3_2 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `gdc3_2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gdc3_2`;

-- 테이블 gdc3_2.book_info 구조 내보내기
CREATE TABLE IF NOT EXISTS `book_info` (
  `book_number` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `brief_introduction` varchar(4000) DEFAULT NULL,
  `availability` varchar(255) NOT NULL DEFAULT '가능',
  `lender` varchar(255) NOT NULL DEFAULT 'Non',
  `book_location` varchar(255) NOT NULL,
  `image_location` varchar(255) DEFAULT NULL,
  `image_FileName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`book_number`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.book_info:~17 rows (대략적) 내보내기
/*!40000 ALTER TABLE `book_info` DISABLE KEYS */;
INSERT INTO `book_info` (`book_number`, `title`, `author`, `publisher`, `genre`, `brief_introduction`, `availability`, `lender`, `book_location`, `image_location`, `image_FileName`) VALUES
	(1, '이것이 C샵이다', '박상현', '한빛미디어', '컴퓨터/IT', '한 번 배울 때 제대로, 기본기부터 탄탄히 다지고 간다!\r\n이 책은 C# .NET 프레임워크 세계에 첫 발을 들이는 입문자를 위한 책이다. 따라서 딱딱하지 않은 대화식 표현으로 1:1 강의처럼 배울 수 있는 것이 이 책의 가장 큰 장점이다. 또한 C#의 핵심 문법은 물론, 프로그래밍 동작 원리까지도 입문자 입장에서 하나하나 꼼꼼히 설명하였다. \r\n책을 덮을 때쯤이면 기초 문법부터, 고급 문법, 그리고 .NET 프레임워크의 활용까지 C#의 전반적인 큰 틀을 자연스레 익힐 수 있을 것이다.\r\n『이것이 C#이다』로 C# 프로그래밍을 시작한다면, 튼튼한 기본기가 갖춰져, 더 이상 실전과 응용도 두렵지 않다! \r\n', '가능', 'Non', 'A-1', 'http://ljh5432.iptime.org:5000/e3976b00-3b8c-4844-8223-4eed565e0e28.png', '이것이 C샵이다.png'),
	(2, '시작하세요 C# 7.1 프로그래밍', '저자값', '출판사값', '장르값', '이 책의 목표는 확실하다. 여러분들이 프로그램을 만들고자 할 때 사용하게 될 프로그래밍 언어인 C#의 기초를 단단하게 다질 수 있도록 이 책을 구성했다. C# 언어를 최신의 7.1 문법까지 설명하고 있으며, 나아가 단순히 언어의 문법 습득에 그치지 않고 실제로 프로그램을 제작할 수 있는 단계까지 학습할 수 있게 내용을 구성했다. ', '가능', 'Non', 'A열 2 - 1', 'http://ljh5432.iptime.org:5000/be634664-9480-45e8-a22b-571bfc564002.png', '시작하세요 C# 7.1 프로그래밍.png'),
	(3, 'ASp.NET&Core를다루는기술', '박용준', '길벗', '컴퓨터/IT', '기술의 집합체인 ASP.NET을 최신 버전 4.6으로 배운다. .NET 기술을 사용하는 오픈 소스이자 크로스플랫폼인 ASP.NET Core 1.0의 새로운 특징도 학습한다. 특히 ASP.NET Core MVC는 Web Pages, Web API, MVC를 하나로 통합하여 관리할 수 있다. 새로운 Web Forms과 MVC 프레임워크를 한 권으로 익혀 보자. ', '가능', 'Non', 'A-3', 'http://ljh5432.iptime.org:5000/398e4654-ffff-42f4-b8e3-600183f8d3b4.png', 'ASp.NET&Core를다루는기술.png'),
	(7, 'Do it! 점프 투 파이썬', '박응용', '이지스퍼블리싱', '컴퓨터/IT', '코딩을 처음 배우는 중·고등학생과 나만의 경쟁력을 갖추고 싶은 문과생, 소프트웨어 시대에 대비하여 새로운 스펙을 준비하려는 직장인까지! 모두 ‘점프 투 파이썬’으로 프로그래밍을 시작했다!\r\n\r\n파이썬 3버전을 기준으로 집필된 《Do it! 점프 투 파이썬》은 첫째마당에서 실생활 속 사례를 접목해 머리에 쏙쏙 박히는 문법 설명을 읽은 후 예제로 익히고, 둘째마당에서 스스로 프로그램을 만들 수 있는 실력 키우기 훈련을 거친다. 이 책과 함께 하루 한 시간, 한 달이면 누구나 초보 딱지 떼고 파이썬 프로그래밍을 정복할 수 있다!', '가능', 'Non', 'C-31', 'http://ljh5432.iptime.org:5000/b40a8e62-ae58-45d0-bb9d-1d8f16252add.png', '점프 투 파이썬.png'),
	(8, '아쿠아맨 Vol.1:침몰', '댄 애브넷', '시공그래픽노블', '그래픽노블', '아틀란티스의 왕 아쿠아맨은 여전히 육지와 해저, 두 세계 사이의 다리가 되기 위해 노력하고 있다. 대립하는 육지와 해저의 관계를 중재하려는 바다의 왕을, 복수심에 불타는 숙적 블랙 만타는 내버려두지 않는다. 블랙 만타가 두 세계의 화평을 도모하는 자리에 나타나 테러를 일으키자 아틀란티스에 대한 지상의 반감은 커져만 가는데...', '가능', 'Non', 'A열 5 - 1', 'http://ljh5432.iptime.org:5000/fce77b26-1e53-478d-b01a-8a8096668199.jpg', '8952793498_1 (1).jpg'),
	(10, '아쿠아맨 Vol.2:디 아더스', '제프 존스', '시공그래픽노블', '그래픽노블', '지구 표면 대부분을 덮고 있는 거대한 대양, 아쿠아맨은 이를 지배하는 바다의 군주이다. 그러나 육지인들은, 비록 아쿠아맨과 그의 치명적인 연인 메라가 자신들을 지켜 줌에도 불구하고 그를 인정하지 않는다. 인간은 바다를 가벼이 여기듯 아쿠아맨 역시 깔보고 우습게 여긴다. 지상의 인간은 아쿠아맨을 원하지 않는다. 그래도 육지인들에겐 그가 필요했다. \r\n\r\n아쿠아맨 외에도 파도 아래 군림하는 이들이 있었다. 어느 날 해구가 열리고 깊고 어두컴컴한 곳, 빛 한 줄기 닿지 않고 오직 굶주림과 증오만이 가득한 그곳에서 새로운 위험이 수면 위로 올라와 뭍을 덮친다. 실체를 드러낸 공포 앞에서 아쿠아맨은 선택의 기로에 놓인다. 하나의 종을 살리기 위해 또 다른 종을 절멸시켜야 하는 상황에 놓인 그는 과연 어떤 길을 택할 것인가….', '가능', 'Non', 'A열 5 - 2', 'http://ljh5432.iptime.org:5000/fd38d879-bc21-471e-9eeb-b1b59e3927bf.jpg', '8952779274_1.jpg'),
	(11, 'DC 아쿠아맨 아트북', '마이크 아빌라', '아르누보', '잡지/화보', '〈아쿠아맨〉 영화 개봉에 맞춰 출간되는 《아쿠아맨 아트북》은 기존의 DC팬들은 물론, 새로이 유입될 팬들을 만족시킬 아쿠아맨의 모든 것을 담고 있다. 영화는 화려한 볼거리와 흥미진진한 스토리와 웃음으로 무장했다면 《아쿠아맨 아트북》은 책에서만 볼 수 있는 배우들의 인터뷰와 제작 비하인드 스토리 등 많은 이야기들을 담았다.', '가능', 'Non', 'A열 5 - 3', 'http://ljh5432.iptime.org:5000/80c47216-589a-4142-b91b-fca134371a55.jpg', 'k202534618_1.jpg'),
	(12, '아쿠아맨 Vol.3 : 아틀란티스의 왕좌 ', '제프 존스', '시공그래픽노블', '그래픽노블', '수수께끼의 세력이 아틀란티스와 육지 세계 사이에 전쟁을 부추긴다. 어떤 이유에선지 육지에서 발사된 미사일에 폭격을 당한 아틀란티스는 이를 공격으로 받아들여 전면 대응에 나선다. 아틀란티스의 왕이자 아쿠아맨의 동생인 옴은 선두에 서서 메트로폴리스와 고담을 비롯한 육지 곳곳을 침몰시킨다. 무수한 희생자가 발생하고, 한때 아틀란티스의 왕이었으나 이제 저스티스 리그의 입장에서 혈육과 동족을 마주한 아쿠아맨은 큰 갈등에 빠진다. \r\n\r\n그런 그의 반응을 이해하지 못하는 저스티스 리그의 동료들은 무력으로 대항하지 않으려는 아쿠아맨과 대립하게 되는데…! 해저에는 동생을, 지상에는 동료를 가진 아쿠아맨은 과연 서로간의 오해를 종식시키고 싸움을 멈출 수 있을 것인가?!', '가능', 'Non', 'A열 5 - 4', 'http://ljh5432.iptime.org:5000/8bb5d59f-7869-4aa8-a86e-f906c4a2d4c2.jpg', '8952790189_1.jpg'),
	(13, '아쿠아맨 Vol.4 : 왕의 죽음', '제프 존스', '시공그래픽노블', '그래픽노블', '아틀란티스와 지상 세계가 벌인 전쟁이 끝나고, 전쟁을 선동한 자들은 모두 갇힌다. 세계는 잠시나마 불안정한 평화를 누린다. 아쿠아맨으로 알려진 슈퍼 히어로, 아서 커리는 왕의 신분으로 아틀란티스를 통치한다. 그러나 그 통치는 시작도 하기 전에 끝날 위기를 맞는다. \r\n\r\n아틀란티스 내부에서는 아쿠아맨의 심복 중 일부가 아서를 왕좌에서 끌어내리고 호전적인 그의 동생 옴을 새로운 왕으로 추대할 음모를 꾸민다. 바다 어딘가에서는 핵잠수함 선단을 이끄는 악당 스캐빈저가 아틀란티스의 무기를 끌어 모아 세계 곳곳에 흩뿌린다. 그의 꿍꿍이는 과연 무엇일까?\r\n', '가능', 'Non', 'A열 5 - 5', 'http://ljh5432.iptime.org:5000/a61dcb54-4eb8-4b1d-9ad5-db46d9441ba2.jpg', '8952790197_1.jpg'),
	(14, '아쿠아맨 Vol.1 : 해구 괴물 ', '제프 존스', '시공그래픽노블', '그래픽노블', '지구 표면 대부분을 덮고 있는 거대한 대양, 아쿠아맨은 이를 지배하는 바다의 군주이다. 그러나 육지인들은, 비록 아쿠아맨과 그의 치명적인 연인 메라가 자신들을 지켜 줌에도 불구하고 그를 인정하지 않는다. 인간은 바다를 가벼이 여기듯 아쿠아맨 역시 깔보고 우습게 여긴다. 지상의 인간은 아쿠아맨을 원하지 않는다. 그래도 육지인들에겐 그가 필요했다. \r\n\r\n아쿠아맨 외에도 파도 아래 군림하는 이들이 있었다. 어느 날 해구가 열리고 깊고 어두컴컴한 곳, 빛 한 줄기 닿지 않고 오직 굶주림과 증오만이 가득한 그곳에서 새로운 위험이 수면 위로 올라와 뭍을 덮친다. 실체를 드러낸 공포 앞에서 아쿠아맨은 선택의 기로에 놓인다. 하나의 종을 살리기 위해 또 다른 종을 절멸시켜야 하는 상황에 놓인 그는 과연 어떤 길을 택할 것인가….', '가능', 'Non', 'A열 5 - 6', 'http://ljh5432.iptime.org:5000/660a6a61-490f-4ce1-b054-efeef1c68192.jpg', '8952777735_1.jpg'),
	(17, '뇌를 자극하는 ASP.NET 2.0', '이시환', '한빛미디어', 'IT', '반복적인 코딩 작업은 이제 그만! 코드량을 최대 70%까지 확~줄여줍니다.\r\nASP.NET 2.0의 개념부터 상세하고 친절하게 알려주어 웹 프로그래밍 경험이 없는 독자도 쉽게 웹 프로그래밍을 시작할 수 있다. ASP.NET 2.0이 지향하는 Codeless(코드량을 혁신적으로 줄인 개발 방법)에 맞춘 예제들은 생산성을 높이는 방법을 일깨워준다. 매번 웹 사이트를 구현할 때마다 똑같은 삽질을 하고 있다는 자괴감에 빠진 개발자에게는 더욱 안성맞춤이다. 중요한 대목에서는 예제만 살펴보고 끝내지 않는다. 호기심을 자극하는 ‘비타민 퀴즈’, 머리 속이 깔끔하게 정리되는 ‘실습문제’를 낸다. 이 책을 읽다 보면 개발자의 수고를 획기적으로 덜어주는 "친절한" ASP.NET 2.0을 만나게 될 것이다.', '가능', 'Non', 'A열 5 - 1', 'http://ljh5432.iptime.org:5000/3ae5747c-110b-4513-9cc7-2e4ae6e6a071.png', '뇌를 자극하는 ASP.NET 2.0 프로그래밍.png'),
	(18, '문장구조 덕분에 영어 공부가 쉬워졌습니다 ', '키 영어학습방법연구소', '키출판사', '전문서적', '언어는 문장구조 규칙만 안다면 무궁무진한 문장을 만들어내는 것이 가능하다. 많고 많은 문장들을 모두 외울 수는 없는 법! 단순한 문장 몇 개를 반복 암기하는 것은 시간 낭비이다. 이 책의 ‘66개의 UNIT’에 제시된 ‘문장구조 분석’을 통해 어떤 길고 복잡한 문장도 쉽게 해석되고 이해할 수 있다.', '가능', 'Non', 'B열 1 - 1', 'http://ljh5432.iptime.org:5000/e0f455b3-e864-4609-b59f-eb862a127acf.jpg', 'k322534510_1.jpg'),
	(19, 'c#코딩의 기술', '영진', '테스트', '테스트', '테스트', '가능', 'Non', '테스트', 'http://ljh5432.iptime.org:5000/86f06da0-1c0d-4b53-9860-10871ebfa49f.jpg', 'k542433551_1.jpg'),
	(20, 'C# 코딩의 기술 기본편', '기와마타 아카리', '길벗', '전문서적', '바로 하나의 코드를 던져주며 이 코드에서 놓치고 있는 함정은 무엇인지, 예고된 버그의 온상은 어디인지, 무엇을 어떻게 수정하면 좋을지를 스토리와 함께 쉽고 재미있게 알려준다. 이 책은 단순히 좋은 코드와 나쁜 코드를 비교하면서 고급 수준의 코딩 스킬을 알려주는 책은 아니다. 그보다는 개발자들이 실무 현장에서 맞닥뜨리는 수많은 문제들을 보다 똑똑하고 현명하게 해결할 수 있도록 발상을 전환하고 문제 해결의 포인트를 정확히 짚을 수 있는 정수를 알려주는 책이다.', '가능', 'Non', 'B열 1 - 3', 'http://ljh5432.iptime.org:5000/86f06da0-1c0d-4b53-9860-10871ebfa49f.jpg', 'k542433551_1.jpg'),
	(21, 'C# 코딩의 기술 기본편', '기와마타 아카리', '길벗', '전문서적', '바로 하나의 코드를 던져주며 이 코드에서 놓치고 있는 함정은 무엇인지, 예고된 버그의 온상은 어디인지, 무엇을 어떻게 수정하면 좋을지를 스토리와 함께 쉽고 재미있게 알려준다. 이 책은 단순히 좋은 코드와 나쁜 코드를 비교하면서 고급 수준의 코딩 스킬을 알려주는 책은 아니다. 그보다는 개발자들이 실무 현장에서 맞닥뜨리는 수많은 문제들을 보다 똑똑하고 현명하게 해결할 수 있도록 발상을 전환하고 문제 해결의 포인트를 정확히 짚을 수 있는 정수를 알려주는 책이다.', '가능', 'Non', 'B열 1 - 4', 'http://ljh5432.iptime.org:5000/86f06da0-1c0d-4b53-9860-10871ebfa49f.jpg', 'k542433551_1.jpg'),
	(22, 'C# 코딩의 기술 기본편', '기와마타 아카리', '길벗', '전문서적', '바로 하나의 코드를 던져주며 이 코드에서 놓치고 있는 함정은 무엇인지, 예고된 버그의 온상은 어디인지, 무엇을 어떻게 수정하면 좋을지를 스토리와 함께 쉽고 재미있게 알려준다. 이 책은 단순히 좋은 코드와 나쁜 코드를 비교하면서 고급 수준의 코딩 스킬을 알려주는 책은 아니다. 그보다는 개발자들이 실무 현장에서 맞닥뜨리는 수많은 문제들을 보다 똑똑하고 현명하게 해결할 수 있도록 발상을 전환하고 문제 해결의 포인트를 정확히 짚을 수 있는 정수를 알려주는 책이다.', '가능', 'Non', 'B열 1 - 5', 'http://ljh5432.iptime.org:5000/86f06da0-1c0d-4b53-9860-10871ebfa49f.jpg', 'k542433551_1.jpg'),
	(23, 'zz', 'z', '와우zz', '와우zz', 'DDD', '가능', 'Non', 'B', 'http://ljh5432.iptime.org:5000/363fa2a0-711c-4e66-b7c9-4df032afebe1.jpg', 'KxvAM6Q.jpg');
/*!40000 ALTER TABLE `book_info` ENABLE KEYS */;

-- 테이블 gdc3_2.book_rental 구조 내보내기
CREATE TABLE IF NOT EXISTS `book_rental` (
  `rental_number` int(11) NOT NULL AUTO_INCREMENT,
  `book_number` int(11) NOT NULL,
  `user_number` int(11) NOT NULL,
  `rental_day` date NOT NULL DEFAULT curdate(),
  `return_schedule` date NOT NULL DEFAULT (curdate() + interval 14 day),
  `return_day` date DEFAULT NULL,
  `rental_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rental_number`),
  KEY `FK_book_rental_signup` (`user_number`),
  KEY `FK_book_rental_book_info` (`book_number`),
  CONSTRAINT `FK_book_rental_book_info` FOREIGN KEY (`book_number`) REFERENCES `book_info` (`book_number`),
  CONSTRAINT `FK_book_rental_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.book_rental:~26 rows (대략적) 내보내기
/*!40000 ALTER TABLE `book_rental` DISABLE KEYS */;
INSERT INTO `book_rental` (`rental_number`, `book_number`, `user_number`, `rental_day`, `return_schedule`, `return_day`, `rental_status`) VALUES
	(53, 7, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(54, 1, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(55, 8, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(56, 7, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(57, 3, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(58, 2, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(59, 19, 5, '2018-12-26', '2018-01-09', NULL, 2),
	(60, 1, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(61, 2, 3, '2018-12-26', '2019-01-09', NULL, 2),
	(62, 1, 1, '2018-12-27', '2019-01-10', NULL, 2),
	(63, 2, 1, '2018-12-27', '2019-01-10', NULL, 2),
	(64, 7, 5, '2018-12-27', '2019-01-10', NULL, 2),
	(65, 3, 5, '2018-12-27', '2019-01-10', NULL, 2),
	(66, 8, 4, '2018-12-27', '2019-01-10', NULL, 2),
	(67, 7, 5, '2018-12-27', '2019-01-10', NULL, 2),
	(68, 11, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(69, 12, 6, '2018-12-28', '2019-01-11', NULL, 2),
	(70, 11, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(71, 13, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(72, 14, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(73, 17, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(74, 18, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(75, 19, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(76, 3, 3, '2018-12-28', '2019-01-11', NULL, 2),
	(77, 7, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(78, 11, 5, '2018-12-28', '2019-01-11', NULL, 2);
/*!40000 ALTER TABLE `book_rental` ENABLE KEYS */;

-- 프로시저 gdc3_2.p_book_count_api 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_count_api`(_book_name VARCHAR(255))
BEGIN

	select title, count(*) COUNT from book_info where title = _book_name;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_bookinfo_config_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_bookinfo_config_update`(in _book_number int,in _title VARCHAR(255),in _author VARCHAR(255),in _publisher VARCHAR(255),in _genre VARCHAR(255),in _brief_introduction VARCHAR(255),in _book_location VARCHAR(255))
BEGIN
	
	update book_info SET 
		title = _title, 
		author = _author, 
		publisher = _publisher, 
		genre = _genre, 
		brief_introduction = _brief_introduction,
		book_location = _book_location 
	where 
		book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_form_listview 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_form_listview`()
BEGIN
	
select book_number, availability, title, author, publisher from book_info;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_insert_book_rental_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_insert_book_rental_update`(_book_number int,_user_number int)
BEGIN
	
INSERT INTO book_rental(book_number, user_number) VALUES(_book_number, _user_number); update book_info set availability = '불가' where book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_listview_click_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_listview_click_select_post`(_book_number int)
BEGIN
	
select * from book_info where book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_search_category_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_search_category_select_post`(_search_category varchar(255), _search_text varchar(255))
BEGIN

SET @Query = CONCAT("select * from book_info where ",_search_category, " LIKE ", '''%',_search_text,'%''', ";");

PREPARE stmt FROM  @Query;
EXECUTE  stmt;
DEALLOCATE PREPARE stmt; 

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_mgt_register_btn 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_mgt_register_btn`(_title VARCHAR(255),_author VARCHAR(255),_publisher VARCHAR(255),_genre VARCHAR(255),_book_location VARCHAR(255),_brief_introduction VARCHAR(255),_image_location VARCHAR(255),_image_FileName VARCHAR(255))
BEGIN

	insert into book_info(
		title, 
		author, 
		publisher, 
		genre, 
		book_location, 
		brief_introduction, 
		image_location, 
		image_FileName) 
		VALUES(
		_title, 
		_author, 
		_publisher, 
		_genre, 
		_book_location, 
		_brief_introduction, 
		_image_location, 
		_image_FileName);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_mgt_request_listview_click_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_mgt_request_listview_click_select_post`(_request_number int)
BEGIN

	select 
		R.request_number, 
		S.user_number, 
		S.name, R.title, 
		R.author, 
		R.publisher, 
		R.genre 
		from signup S inner join Receiving_equest R on (S.user_number = R.user_number and R.request_number = _request_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_common_create_ctl_delay_rental_check 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_common_create_ctl_delay_rental_check`(IN _rental_status varchar(255))
BEGIN

update book_rental set rental_status = _rental_status where rental_number in (select rental_number from book_rental where (TO_DAYS(now()) - TO_DAYS(return_schedule)) > 0 and rental_status <> 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_detail_book_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_detail_book_info`(_book_name VARCHAR(255))
BEGIN

	select * from book_info where title = _book_name;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_GetUPDATE_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_GetUPDATE_API`(_email VARCHAR(255),_Phon VARCHAR(255),_addres VARCHAR(255),_user_number int)
BEGIN

	UPDATE signup set email = _email,phone_number = _Phon,address = _addres where user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_GetUPDATE_Pass_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_GetUPDATE_Pass_API`(_passwod VARCHAR(255),_user_number int)
BEGIN

	UPDATE signup set passwod = _passwod where user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_late_mgt_listview_delay_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_late_mgt_listview_delay_info`()
BEGIN

	select S.user_number, S.phone_number, S.name, I.title, I.book_number, R.rental_day, TO_DAYS(now()) - TO_DAYS(R.return_schedule) 연체일 from book_info as I inner join book_rental as R on (I.book_number = R.book_number and TO_DAYS(now()) - TO_DAYS(R.return_schedule) > 0 and R.rental_status <> 2) inner join signup as S on (S.user_number = R.user_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_login_form_PW_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_login_form_PW_Select_API`(_id VARCHAR(255))
BEGIN

	select passwod  from signup where id = _id;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_Passwod_Check_PW_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_Passwod_Check_PW_Select_API`(_PWtext VARCHAR(255),_user_number int)
BEGIN

	select passwod from signup where passwod = _PWtext && user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_book_info_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_book_info_update`(_no int)
BEGIN

update book_info set availability = '가능' where book_number in (select book_number from book_rental where rental_number = _no and rental_status = 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_book_rental_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_book_rental_update`(_no int)
BEGIN

update book_rental set rental_status = 2 WHERE rental_number = _no;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_form_GetSelect 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_form_GetSelect`(_user_number int)
BEGIN

	select R.rental_number 대여번호,	I.title 도서명, I.author 저자, I.publisher 출판사, R.rental_day 대여일, R.return_schedule 반납일, case when TO_DAYS(now()) - TO_DAYS(return_schedule) > 0 then '연체됨' when TO_DAYS(now()) - TO_DAYS(return_schedule) <= 0 then '연체안됨' else '' end 연체일, case when R.rental_status = 0 then '대여중' when R.rental_status = 1 then '반납요망' else '' end 상태 from	book_info as I inner join book_rental as R on (I.book_number = R.book_number) WHERE R.user_number = _user_number && (R.rental_status = 1 || R.rental_status = 0);
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_book_form_request_register 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_book_form_request_register`(_title VARCHAR(255),_author VARCHAR(255),_publisher VARCHAR(255),_genre VARCHAR(255),_user_number int)
BEGIN


insert into Receiving_equest(title, author, publisher, genre, user_number) values(_title, _author, _publisher, _genre, _user_number);


END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_listview 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_listview`()
BEGIN
	
	select R.request_number, 
		S.user_number, 
		S.name, R.title, 
		R.author, 
		R.publisher,
		R.genre 
		from signup S inner join Receiving_equest R on (S.user_number = R.user_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_list_delete 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_list_delete`(_request_number int)
BEGIN

	delete from Receiving_equest where request_number = _request_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_Select_signup_info_Webapi 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_Select_signup_info_Webapi`()
BEGIN

select * from signup;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_signup_form_GetInsert 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_signup_form_GetInsert`(IN _ID varchar(255),IN  _Pass varchar(255),IN  _Name varchar(255),IN  _Gender varchar(255),IN  _Birth varchar(255),IN  _email varchar(255), _Phon varchar(255), _addres varchar(255))
BEGIN

INSERT INTO signup(id,passwod,name,gender,birthday,email,phone_number,address)  values (_ID,_Pass,_Name,_Gender,_Birth,_email,_Phon,_addres);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_signup_user_number_GetSelect_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_signup_user_number_GetSelect_API`(_user VARCHAR(255))
BEGIN

	select * from signup where user_number = _user;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_blackList_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_blackList_select_post`(_user_number int)
BEGIN

SELECT blacklist FROM signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_ID_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_ID_Select_API`(_PWtext VARCHAR(255))
BEGIN

	select id from signup where passwod = _PWtext;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_info_search 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_info_search`(IN _search_category varchar(255),IN _textbox_search varchar(255))
BEGIN

SET @Query = CONCAT("select * from signup where ",_search_category, " LIKE ", '''%',_textbox_search,'%''', ";");

PREPARE stmt FROM  @Query;
EXECUTE  stmt;
DEALLOCATE PREPARE stmt; 

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_rental_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_rental_info`(
	IN `_user_number` int
)
BEGIN

select	R.rental_number, I.book_number, I.title, I.author, I.publisher, case when R.rental_status = 0 then '대여중' when R.rental_status = 1 then '미반납' end as 'rental_status' from	book_info I inner join	book_rental  R on (R.user_number = _user_number and I.book_number = R.book_number and R.rental_status <> 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_signup 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_signup`(IN _user_number int)
BEGIN

select * from signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_blacklist_N_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_blacklist_N_set`(IN _user_number int)
BEGIN

update signup set blacklist = 'N' where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_blacklist_Y_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_blacklist_Y_set`(IN _user_number int)
BEGIN

update signup set blacklist = 'Y' where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_member_rank_0_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_member_rank_0_set`(IN _user_number int)
BEGIN

update signup set member_rank = 0 where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_member_rank_1_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_member_rank_1_set`(IN _user_number int)
BEGIN

update signup set member_rank = 1 where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_user_number_signup_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_user_number_signup_info`(IN _user_number int)
BEGIN

select * from signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_User_Number_Member_Rank_Chk_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_User_Number_Member_Rank_Chk_API`(_id VARCHAR(255),_pw VARCHAR(255))
BEGIN

	select user_number, member_rank from signup where id = _id && passwod = _pw;
	
END//
DELIMITER ;

-- 테이블 gdc3_2.Receiving_equest 구조 내보내기
CREATE TABLE IF NOT EXISTS `Receiving_equest` (
  `request_number` int(11) NOT NULL AUTO_INCREMENT,
  `user_number` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `Request_date` date DEFAULT curdate(),
  PRIMARY KEY (`request_number`),
  KEY `FK_Receiving_equest_signup` (`user_number`),
  CONSTRAINT `FK_Receiving_equest_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.Receiving_equest:~2 rows (대략적) 내보내기
/*!40000 ALTER TABLE `Receiving_equest` DISABLE KEYS */;
/*!40000 ALTER TABLE `Receiving_equest` ENABLE KEYS */;

-- 테이블 gdc3_2.signup 구조 내보내기
CREATE TABLE IF NOT EXISTS `signup` (
  `user_number` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `passwod` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `blacklist` varchar(255) DEFAULT 'N',
  `member_rank` int(11) DEFAULT 1,
  PRIMARY KEY (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.signup:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` (`user_number`, `id`, `passwod`, `name`, `gender`, `birthday`, `email`, `phone_number`, `address`, `blacklist`, `member_rank`) VALUES
	(1, 'root', '1234', '관리자', '성별', '2018-12-17', 'hlc@naver.com', '010-0000-0000', '서울특별시 금천구 가산동 가산디지털2로', 'N', 0),
	(3, 'user1', '1234', '워로드', '남', '1995-03-18', 'LoastArk@smile.com', '010-7616-0770', '안타레스4채널', 'N', 1),
	(4, 'ljh5432', '1234', '이지현', '남', '1988-04-27', 'ljh5432@gmail.com', '010-0000-0000', '동대문구 장안 1동 ', 'N', 1),
	(5, 'user2', '1234', '호랭이', '수컷', '0900-03-18', 'Tiger9@naver.com', '010-0110-0000', '백두산 산군시 호랑이굴 1번지', 'N', 1),
	(6, '아쿠아맨', '1234', '존 아서', '남', '1990-03-18', '3G창@water.com', '010-0000-2222', '아틀란티스 궁궐', 'N', 1),
	(7, '1234', '1234', '123', '1995-03-18-월-', '1995-03-18', 'chyj0381@naver.com', '000-0000-0000', '000000000', 'N', 1);
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;

-- 프로시저 gdc3_2.user_blackList_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `user_blackList_select_post`(_user_number int)
BEGIN

SELECT blacklist FROM signup where user_number = _user_number;

END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
