select * from book_info where {0} LIKE '%{1}%'", search_category, search_text
select * from book_info where title LIKE '%아쿠아맨%';

DROP PROCEDURE book_info_search_category_select_post;

DELIMITER // 
CREATE PROCEDURE book_info_search_category_select_post(_search_category varchar(255), _search_text varchar(255))
BEGIN

SET @Query = CONCAT("select * from book_info where ",_search_category, " LIKE ", '''%',_search_text,'%''', ";");

PREPARE stmt FROM  @Query;
EXECUTE  stmt;
DEALLOCATE PREPARE stmt; 

END//
DELIMITER ;

call book_info_search_category_select_post('author','박상현');

call book_info_search_category_select_post('title','아쿠아');

call book_info_search_category_select_post('publisher','한빛미디어');



