

DELIMITER // 
CREATE PROCEDURE p_common_create_ctl_delay_rental_check(IN _rental_status varchar(255))
BEGIN

update book_rental set rental_status = _rental_status where rental_number in (select rental_number from book_rental where (TO_DAYS(now()) - TO_DAYS(return_schedule)) > 0 and rental_status <> 2);

END//
DELIMITER ;


DELIMITER // 
CREATE PROCEDURE p_user_level_update_form_signup_member_rank_1_set(IN _user_number varchar(255))
BEGIN

update signup set member_rank = 1 where user_number = _user_number;

END//
DELIMITER ;


DELIMITER // 
CREATE PROCEDURE p_user_level_update_form_signup_member_rank_0_set(IN _user_number varchar(255))
BEGIN

update signup set member_rank = 0 where user_number = _user_number;

END//
DELIMITER ;



DELIMITER // 
CREATE PROCEDURE p_user_level_update_form_user_number_signup_info(IN _user_number varchar(255))
BEGIN

update select * from signup where user_number = _user_number;

END//
DELIMITER ;



DELIMITER // 
CREATE PROCEDURE p_user_info_form_user_info_search(IN _search_category varchar(255),IN _textbox_search varchar(255))
BEGIN

SET @Query = CONCAT("select * from signup where ",_search_category, " LIKE ", '''%',_textbox_search,'%''', ";");

PREPARE stmt FROM  @Query;
EXECUTE  stmt;
DEALLOCATE PREPARE stmt; 

END//
DELIMITER ;



DELIMITER // 
CREATE PROCEDURE p_user_info_form_user_rental_info(IN _user_number varchar(255))
BEGIN

select	I.book_number, I.title, I.author, I.publisher, case when R.rental_status = 0 then '대여중' when R.rental_status = 1 then '미반납' end as 'rental_status' from	book_info I inner join	book_rental  R on (R.user_number = _user_number and I.book_number = R.book_number and R.rental_status <> 2);

END//
DELIMITER ;


DELIMITER // 
CREATE PROCEDURE p_user_info_form_user_signup(IN _user_number varchar(255))
BEGIN

select * from signup where user_number = _user_number;

END//
DELIMITER ;


DELIMITER // 
CREATE PROCEDURE p_signup_form_GetInsert(IN _ID varchar(255),IN  _Pass varchar(255),IN  _Name varchar(255),IN  _Gender varchar(255),IN  _Birth varchar(255),IN  _email varchar(255), _Phon varchar(255), _addres varchar(255))
BEGIN

INSERT INTO signup(id,passwod,name,gender,birthday,email,phone_number,address)  values (_ID,_Pass,_Name,_Gender,_Birth,_email,_Phon,_addres);

END//
DELIMITER ;


DELIMITER // 
CREATE PROCEDURE p_request_book_form_request_register(IN _title varchar(255),IN  _author varchar(255),IN  _publisher varchar(255),IN  _genre varchar(255),IN  _user_number varchar(255))
BEGIN

insert into Receiving_equest(title, author, publisher, genre, user_number) values (_title,_author,_publisher,_genre,_user_number);

END//
DELIMITER ;